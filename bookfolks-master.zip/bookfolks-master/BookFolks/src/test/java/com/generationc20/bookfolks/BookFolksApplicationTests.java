package com.generationc20.bookfolks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookFolksApplicationTests {

	@Test
	void contextLoads() {
	}

}
