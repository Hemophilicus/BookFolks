package com.generationc20.bookfolks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookFolksApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookFolksApplication.class, args);
	}

}
